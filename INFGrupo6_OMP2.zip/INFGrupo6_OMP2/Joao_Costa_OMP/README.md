# Joao_Costa_OMP
 omp
