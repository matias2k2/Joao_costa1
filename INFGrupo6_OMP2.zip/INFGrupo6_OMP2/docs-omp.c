#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include<omp.h>

int main(int argc, char *argv[]){
	
	//variaveis iniciais
	char nomeDoc[40], nomeFile[40];	
	
	//leitura das informacoes iniciais
	scanf("%s", nomeFile);
	
	//inicio do programa
	printf("\n---ENGINE START--- \n");
	
	//contagem do tempo
	double tempo_ini = 0;
	tempo_ini = omp_get_wtime();
	
	//armarios, documentos, assuntos
	int C, D, S;
	C = D = S = 0;
	
	//variaveis de controle - auxiliares
	int controlC = 1; int controlD = 0; int controlS = 0; int flag = 0; int i, j, k;
	char temp[10];
	
	//carregando o ficheiro com as informacoes
	FILE * ficheiro;
	ficheiro = fopen(nomeFile, "r");
	
	//ler o numero de documentos, armarios e assuntos contidos no ficheiro - 3 iteracoes
	while(fscanf(ficheiro, "%s", temp)>0){
		//atribuicao dos armarios
		if(controlC == 1){
			C = atoi(temp);
			controlC = 0;
			controlD = 1;
			i++;
			goto fimL1;
		}
		//atribuicao do valor dos documentos
		if(controlD == 1){
			D = atoi(temp);
			controlD = 0;
			controlS = 1;
			i++;
			goto fimL1;
		}
		//atribuicao dos assuntos
		if(controlS == 1){
			S = atoi(temp);
			controlS = 0;
			i++;
			goto fimL1;
		}
		fimL1:
			if(i == 3){
				//fechamos o ficheiro para podermos declarar a variavel docs e armario fora do ciclo
				fclose(ficheiro);
			} 
	}
	
	//criacao do vector de documentos
	float docs[D][S]; 
	
	//zerando as variaveis de controle
	j = k = flag = 0;
	i = 1;
	//limpando a string temporaria
	temp[0] = '\0';
	
	//reabertura do ficheiro e leitura do restante ficheiro
	ficheiro = fopen(nomeFile, "r");
	while(fscanf(ficheiro, "%s", temp)>0){
		if(i<4){
			//ignorar os 3 primeiros valores
			i++;
			goto fimL2;
		}else{
			if(flag == 0){
				//pegar o numero do doc
				j = atoi(temp);
				flag = 1;
				goto fimL2;
			}else{
				//pegar as pontuacoes dos assuntos de cada doc
				if(k < S){
					docs[j][k] = atof(temp);
					k++;
					//fim das pontuacoes dos assuntos de cada doc
					if(k == S) {
						k = 0;
						flag = 0;	
					}
				}
			}
			fimL2:
				controlS = 0;
		}
	}//pontuacoes carregadas para os referidos documentos 
	                        
	//encerramento da leitura do ficheiro
	fclose(ficheiro);
	
	//limpeza do buffer
	fflush(stdin);
	
	//definicao das threads
	omp_set_num_threads(4);
	
	//atribuicao inicial dos armarios - Round Robin
	int armarios[D];
	
	#pragma omp parallel for
	for(i = 0; i<D; i++){
		armarios[i] = i % C;
	}
	
	//iteracoes para reorganizar os documentos
	
	//variavel de controle
	flag = 1;
	
	//goto label
	loop:
		
	//inicio das iteracoes
	while(flag == 1){
		flag = 0;
	
		//criacao e inicializacao da media por assuntos
		float media_assuntos_armario[C][S];
		
		#pragma omp parallel for
		for(i = 0; i<C; i++){
			for(j = 0; j<S; j++){
				media_assuntos_armario[i][j] = 0;
			}
		}
			
			//calculo da media de cada assunto
			for(i = 0; i<C; i++){
				//divisores - documentos por armario
				controlD = 0;
				for(j=0; j<D; j++){
					//procurar na lista doc->armarios
					if(armarios[j] == i){
						//se encontrarmos, somamos os valores por assunto
						#pragma OMP parallel for reduction (+: media_assuntos_armario)
						for(k=0; k<S; k++){
							media_assuntos_armario[i][k] += docs[j][k];
						}
						//controlD - controla a quantidade de divisores
						controlD++;
					}
				}
			
				//calculo da media de cada assunto por armario
				#pragma omp parallel for
				for(k = 0; k<S; k++){
					media_assuntos_armario[i][k] = media_assuntos_armario[i][k]/controlD;
				}
				controlD = 0;
			}
		
		//calculo das distancias armarios x documentos
		float distancias[C][D];
		
			for(i=0; i<D; i++){
				//para cada documento
				for(j=0; j<C; j++){
					//para cada armario
					float aux = 0;
					distancias[j][i] = 0;
					
					//para cada assunto
					#pragma OMP parallel for reduction (+: distancias)
					for(k=0; k<S; k++){
						aux = docs[i][k]-media_assuntos_armario[j][k];
						aux = pow(aux, 2);
						distancias[j][i] += aux;
					}
				}
			}
		
		//copiar os dados do armario antigo
		int old_armario[D];
		#pragma omp parallel for
		for(i=0; i<D; i++){
			old_armario[i] = armarios[i];
		}
		
		//organizando os armarios
		float menor = 0;
		//calculo do menor numero e reorganizacao do armario
		#pragma omp parallel for
		for(i=0; i<D; i++){
			menor= distancias[0][D];
			for(j=0; j<C; j++){
				if(menor>distancias[j][i]){
					menor = distancias[j][i];
					armarios[i] = j;
				}
			}
		} 
		
		//verificacao da existencia de alteracoes
		#pragma omp parallel for
		for(k=0; k<D; k++){
			if(armarios[k] != old_armario[k])
				flag = 1;
		}
		if(flag == 1)
			goto loop;
		else
			goto out;
		
	//fim do while
	}
	
	//fim do programa
	out:
		char file_output[40];
		for(i=0; i<40; i++){
			//copiando o nome e adicionando a extensao .out
			if(nomeFile[i] == '.'){
				file_output[i] = nomeFile[i];
				strcat(file_output,"out");
				break;
			}else{
				file_output[i] = nomeFile[i];
			}
		}
	
		//criacao do ficheiro de output
		ficheiro = fopen(file_output, "w");
		for(i=0; i<D; i++){
			fprintf(ficheiro, "%d %d\n",i,armarios[i]);
		}
		fclose(ficheiro);
	
		double tempo_fim = 0;
		tempo_fim = omp_get_wtime();
		printf("Output do file %s\n",file_output);
	
		printf("\ntempo de execucao: %f \n", tempo_fim-tempo_ini);
		printf("fim da execucao \n");
	
		
	
	return 0;
}
