#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int main(int argc, char *argv[]){
	
	//variaveis iniciais
	char nomeDoc[40], nomeFile[40];	
	//leitura das informacoes iniciais
	scanf("%s", nomeFile);
	printf("\n--START--- \n\n");
	
	//armarios, documentos, assuntos
	int C, D, S;
	C = D = S = 0;
	
	//carregando o ficheiro com as informacoes
	FILE * ficheiro;
	
	//variaveis de controle
	int controlC = 1; int controlD = 0; int controlS = 0; int flag = 0; int i, j, k;
	char temp[10];
	
	ficheiro = fopen(nomeFile, "r");
	while(fscanf(ficheiro, "%s", temp)>0){
		//atribuicao dos armarios
		if(controlC == 1){
			C = atoi(temp);
			controlC = 0;
			controlD = 1;
			i++;
			goto fimL1;
		}
		//atribuicao do valor dos documentos
		if(controlD == 1){
			D = atoi(temp);
			controlD = 0;
			controlS = 1;
			i++;
			goto fimL1;
		}
		//atribuicao dos assuntos
		if(controlS == 1){
			S = atoi(temp);
			controlS = 0;
			i++;
			goto fimL1;
		}
		fimL1:
			if(i == 3){
				//fechamos o ficheiro para podermos declarar a variavel docs e armario fora do ciclo
				fclose(ficheiro);
			} 
	}
	
	//criacao do vector de documentos
	float docs[D][S];
	
	//zerando as variaveis de controle
	j = k = flag = 0;
	i = 1;
	//limpando a string temporaria
	temp[0] = '\0';
	
	//reabertura do ficheiro e leitura do restante ficheiro
	ficheiro = fopen(nomeFile, "r");
	while(fscanf(ficheiro, "%s", temp)>0){
		if(i<4){
			//ignorar os 3 primeiros valores
			i++;
			goto fimL2;
		}else{
			if(flag == 0){
				//pegar o numero do doc
				j = atoi(temp);
				flag = 1;
				goto fimL2;
			}else{
				//pegar as pontuacoes dos assuntos de cada doc
				if(k < S){
					docs[j][k] = atof(temp);
					k++;
					//fim das pontuacoes dos assuntos de cada doc
					if(k == S) {
						k = 0;
						flag = 0;	
					}
				}
			}
			fimL2:
				controlS = 0;
		}
	}//pontuacoes carregadas para os referidos documentos                         
	//encerramento da leitura do ficheiro
	fclose(ficheiro);
	
	//limpeza do buffer
	fflush(stdin);
	
	//atribuicao inicial dos armarios - Round Robin
	int armarios[D];
	for(i = 0; i<D; i++){
		armarios[i] = i % C;
	}
	
	//iteracoes para reorganizar os documentos
	flag = 1;
	//goto label
	loop:
	while(flag == 1){
		flag = 0;
		
		//criacao e inicializacao, media por assuntos
		float media_assuntos_armario[C][S];
		for(i = 0; i<C; i++){
			for(j = 0; j<S; j++){
				media_assuntos_armario[i][j] = 0;
			}
		}
		
		//calculo da media de cada assunto - funciona perfeitamente - teste de mesa confirmado
		for(i = 0; i<C; i++){
			
			//divisores - documentos por armario
			controlD = 0;
			for(j=0; j<D; j++){
				//procurar na lista doc->armarios
				if(armarios[j] == i){
					//se encontrarmos, somamos os valores por assunto
					for(k=0; k<S; k++){
						media_assuntos_armario[i][k] += docs[j][k];
					}
					//controlD - controla a quantidade de divisores
					controlD++;
				}
			}
			
			//calculo da media de cada assunto por armario
			for(k = 0; k<S; k++){
				media_assuntos_armario[i][k] = media_assuntos_armario[i][k]/controlD;
			}
			controlD = 0;
			
		}
		
		//calculo das distancias - funciona perfeitamente - teste de mesa confirmado
		float distancias[C][D];
		
		for(i=0; i<D; i++){
		//para cada documento
			for(j=0; j<C; j++){
			//para cada armario
				float aux = 0;
				distancias[j][i] = 0;
				for(k=0; k<S; k++){
				//para cada assunto
					aux = docs[i][k]-media_assuntos_armario[j][k];
					aux = pow(aux, 2);
					distancias[j][i] += aux;
				}
				
			}
		}
		
		//copiar os dados do armario antigo
		int old_armario[D];
		for(i=0; i<D; i++){
			old_armario[i] = armarios[i];
		}
		
		float menor = 0;
		//calculo do menor numero e reorganizacao do armario
		for(i=0; i<D; i++){
			menor= distancias[0][D];
			for(j=0; j<C; j++){
				if(menor>distancias[j][i]){
					menor = distancias[j][i];
					armarios[i] = j;
				}
			}
		} 
		
		//verificacao da existencia de alteracoes
		for(k=0; k<D; k++){
			if(armarios[k] != old_armario[k])
				flag = 1;
		}
		if(flag == 1)
			goto loop;
		else
			goto out;
		
	//fim do while
	}
	
	//fim do programa
	out:
		
		fflush(stdout);
		//nome do ficheiro de saida
		char file_output[40];
	
		for(i=0; i<40; i++){
			//copiando o nome e adicionando a extensao .out
			if(nomeFile[i] == '.'){
				file_output[i] = nomeFile[i];
				strcat(file_output,"out");
				break;
			}else{
				file_output[i] = nomeFile[i];
			}
		}
	
		//criacao do ficheiro de output
		ficheiro = fopen(file_output, "w");
	
		for(i=0; i<D; i++){
			fprintf(ficheiro, "%d %d\n",i,armarios[i]);
		}
	
		fclose(ficheiro);
	
	printf("\n---END OF EXECUTION---\n");
	printf("Output saved on the file %s\n",file_output);
	
	return 0;
	system("Pause");
}
