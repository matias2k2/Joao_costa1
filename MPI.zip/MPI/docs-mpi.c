#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mpi.h>

#define MAX_DOC 10000
#define MAX_ASSUNTO 1000
#define MAX_ARMARIO 1000

double documentos[MAX_DOC][MAX_ASSUNTO];
int documentos_armarios[MAX_DOC];

void atribuicao_inicial(int d, int c)
{
    for (int i = 0; i < d; i++)
    {
        documentos_armarios[i] = i % c;
    }
}

FILE *lerarquivo(char nome[])
{
    FILE *arquivo = fopen(nome, "r");
    if (arquivo == NULL)
    {
        printf("Erro ao abrir o arquivo.\n");
        return NULL;
    }
    else
    {
        printf("Arquivo lido com sucesso.\n");
        return arquivo;
    }
}

int main(int argc, char **argv)
{
    int rank, size;
    int arm, docs, assuntos, ops;
    char nome_arquivo[50];

    MPI_Init(&argc, &argv);
    MPI_Comm_rank(MPI_COMM_WORLD, &rank);
    MPI_Comm_size(MPI_COMM_WORLD, &size);

    if (rank == 0)
    {
        printf("--- Digite o nome do arquivo:\n");
        scanf("%s", nome_arquivo);
    }

    // Broadcast do nome do arquivo para todos os processos
    MPI_Bcast(nome_arquivo, 50, MPI_CHAR, 0, MPI_COMM_WORLD);

    FILE *arquivo = lerarquivo(nome_arquivo);
    if (arquivo != NULL)
    {
        if (rank == 0)
        {
            printf("-- Deseja ler o numero de armarios agora?\n -- Sim(1) Nao(2): ");
            scanf("%d", &ops);
        }

        // Broadcast da opcao para todos os processos
        MPI_Bcast(&ops, 1, MPI_INT, 0, MPI_COMM_WORLD);

        switch (ops)
        {
        case 1:
            if (rank == 0)
            {
                printf("Digite o numero de armarios: ");
                scanf("%d", &arm);
            }

            // Broadcast do numero de armarios para todos os processos
            MPI_Bcast(&arm, 1, MPI_INT, 0, MPI_COMM_WORLD);

            if (rank == 0)
            {
                fscanf(arquivo, "%d %d %d", &arm, &docs, &assuntos);
            }

            // Broadcast do numero de documentos e assuntos para todos os processos
            MPI_Bcast(&docs, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&assuntos, 1, MPI_INT, 0, MPI_COMM_WORLD);

            // Leitura dos documentos para cada processo
            for (int i = 0; i < docs; i++)
            {
                if (rank == 0)
                {
                    fscanf(arquivo, "%*d");
                }
                for (int j = 0; j < assuntos; j++)
                {
                    fscanf(arquivo, "%lf", &documentos[i][j]);
                }
            }

            break;

        case 2:
            if (rank == 0)
            {
                fscanf(arquivo, "%d %d %d", &arm, &docs, &assuntos);
            }

            // Broadcast do numero de armarios, documentos e assuntos para todos os processos
            MPI_Bcast(&arm, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&docs, 1, MPI_INT, 0, MPI_COMM_WORLD);
            MPI_Bcast(&assuntos, 1, MPI_INT, 0, MPI_COMM_WORLD);

            // Leitura dos documentos para cada processo
            for (int i = 0; i < docs; i++)
            {
                if (rank == 0)
                {
                    fscanf(arquivo, "%*d");
                }
                for (int j = 0; j < assuntos; j++)
                {
                    fscanf(arquivo, "%lf", &documentos[i][j]);
                }
            }

            break;

        default:
            if (rank == 0)
            {
                printf("\n-- Opcao inválida\n");
            }
            break;
        }
    }

    MPI_Barrier(MPI_COMM_WORLD); // Sincronizacao de todos os processos

    // Cada processo realiza a atribuicao inicial
    atribuicao_inicial(docs, arm);

    // Exibicao dos primeiros 10 documentos_armarios de cada processo
    for (int i = 0; i < 10; i++)
    {
        printf("Processo %d - documentos_armarios[%d] = %d\n", rank, i, documentos_armarios[i]);
    }

    MPI_Finalize();

    return 0;
}
